using UiPath.CodedWorkflows;
using System;

namespace ApplicationTestingILT
{
    public class ConnectionsManager
    {
        public ConnectionsManager(ICodedWorkflowsServiceContainer resolver)
        {
        }
    }
}