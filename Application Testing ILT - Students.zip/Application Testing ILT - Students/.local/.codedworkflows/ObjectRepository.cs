using UiPath.CodedWorkflows.DescriptorIntegration;

namespace ApplicationTestingILT.ObjectRepository
{
    public static class Descriptors
    {
        public static class UiBank
        {
            static string _reference = "GtvnX6OfOUCtv3dQPEjiDg/USJPiNE6g0ecM8I77ah5MA";
            public static _Implementation._UiBank.__Accounts Accounts { get; private set; } = new _Implementation._UiBank.__Accounts();
            public static _Implementation._UiBank.__Login Login { get; private set; } = new _Implementation._UiBank.__Login();
        }
    }
}

namespace ApplicationTestingILT._Implementation
{
    internal class ScreenDescriptorDefinition : IScreenDescriptorDefinition
    {
        public IScreenDescriptor Screen { get; set; }

        public string Reference { get; set; }

        public string DisplayName { get; set; }
    }

    internal class ElementDescriptorDefinition : IElementDescriptorDefinition
    {
        public IScreenDescriptor Screen { get; set; }

        public string Reference { get; set; }

        public string DisplayName { get; set; }

        public IElementDescriptor ParentElement { get; set; }

        public IElementDescriptor Element { get; set; }
    }

    namespace _UiBank._Accounts
    {
        public class __Welcome_message : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Welcome_message(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "GtvnX6OfOUCtv3dQPEjiDg/0JF1GVO6uEaKpfLJG6ST8w", DisplayName = "Welcome message", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _UiBank
    {
        public class __Accounts : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;
            public __Accounts()
            {
                _screenDescriptor = new ScreenDescriptorDefinition{Reference = "GtvnX6OfOUCtv3dQPEjiDg/ZhvCwNClAkK3iK56kUpGoA", DisplayName = "Accounts", Screen = this};
                Welcome_message = new _Implementation._UiBank._Accounts.__Welcome_message(this, null);
            }

            public _Implementation._UiBank._Accounts.__Welcome_message Welcome_message { get; private set; }
        }
    }

    namespace _UiBank._Login
    {
        public class __Forgot_Your_Password_ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Forgot_Your_Password_(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "GtvnX6OfOUCtv3dQPEjiDg/fRvkQXSQ6US2G2v9nUVgoA", DisplayName = "Forgot Your Password?", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _UiBank._Login
    {
        public class __Logout : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Logout(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "GtvnX6OfOUCtv3dQPEjiDg/0DyXaeGzbUmDXzcXohF5hA", DisplayName = "Logout", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _UiBank._Login
    {
        public class __Password : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Password(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "GtvnX6OfOUCtv3dQPEjiDg/BQANOnMdgUSxMkjrf6vY7w", DisplayName = "Password", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _UiBank._Login
    {
        public class __Register_For_Account : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Register_For_Account(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "GtvnX6OfOUCtv3dQPEjiDg/PcvmfwyGEEqyi3nn7hhgHA", DisplayName = "Register For Account", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _UiBank._Login
    {
        public class __Sign_In : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Sign_In(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "GtvnX6OfOUCtv3dQPEjiDg/FDiNoRWIAUm5tdtu3tBZ_w", DisplayName = "Sign In", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _UiBank._Login
    {
        public class __Username : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Username(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "GtvnX6OfOUCtv3dQPEjiDg/CZUhEWv6N0ik5nuw6gxrFw", DisplayName = "Username", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _UiBank
    {
        public class __Login : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;
            public __Login()
            {
                _screenDescriptor = new ScreenDescriptorDefinition{Reference = "GtvnX6OfOUCtv3dQPEjiDg/VKVL7pn-MEesb9fG1AcuwQ", DisplayName = "Login", Screen = this};
                Forgot_Your_Password_ = new _Implementation._UiBank._Login.__Forgot_Your_Password_(this, null);
                Logout = new _Implementation._UiBank._Login.__Logout(this, null);
                Password = new _Implementation._UiBank._Login.__Password(this, null);
                Register_For_Account = new _Implementation._UiBank._Login.__Register_For_Account(this, null);
                Sign_In = new _Implementation._UiBank._Login.__Sign_In(this, null);
                Username = new _Implementation._UiBank._Login.__Username(this, null);
            }

            public _Implementation._UiBank._Login.__Forgot_Your_Password_ Forgot_Your_Password_ { get; private set; }

            public _Implementation._UiBank._Login.__Logout Logout { get; private set; }

            public _Implementation._UiBank._Login.__Password Password { get; private set; }

            public _Implementation._UiBank._Login.__Register_For_Account Register_For_Account { get; private set; }

            public _Implementation._UiBank._Login.__Sign_In Sign_In { get; private set; }

            public _Implementation._UiBank._Login.__Username Username { get; private set; }
        }
    }
}