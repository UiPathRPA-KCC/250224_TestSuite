using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using UiPath.CodedWorkflows;
using UiPath.Activities.Contracts;

namespace ApplicationTestingILT
{
    public class WorkflowRunnerService
    {
        private readonly Func<string, IDictionary<string, object>, TimeSpan?, bool, InvokeTargetSession, IDictionary<string, object>> _runWorkflowHandler;
        public WorkflowRunnerService(Func<string, IDictionary<string, object>, TimeSpan?, bool, InvokeTargetSession, IDictionary<string, object>> runWorkflowHandler)
        {
            _runWorkflowHandler = runWorkflowHandler;
        }

        /// <summary>
        /// Invokes the 7.APIs/TC_APIs.xaml
        /// </summary>
        public void TC_APIs(string Amount, string Term, string Income, string Age, string Email, string Accepted)
        {
            var result = _runWorkflowHandler(@"7.APIs\TC_APIs.xaml", new Dictionary<string, object>{{"Amount", Amount}, {"Term", Term}, {"Income", Income}, {"Age", Age}, {"Email", Email}, {"Accepted", Accepted}}, default, default, default);
        }

        /// <summary>
        /// Invokes the 8.Databases/TC_DataBase.xaml
        /// </summary>
        public void TC_DataBase(string User_ID, string Given_Name, string Last_Name, string Occupation, string Age, string Loan_Amount, string Yearly_Income)
        {
            var result = _runWorkflowHandler(@"8.Databases\TC_DataBase.xaml", new Dictionary<string, object>{{"User_ID", User_ID}, {"Given_Name", Given_Name}, {"Last_Name", Last_Name}, {"Occupation", Occupation}, {"Age", Age}, {"Loan_Amount", Loan_Amount}, {"Yearly_Income", Yearly_Income}}, default, default, default);
        }

        /// <summary>
        /// Invokes the 9.Terminals/TC_Terminal.xaml
        /// </summary>
        public void TC_Terminal()
        {
            var result = _runWorkflowHandler(@"9.Terminals\TC_Terminal.xaml", new Dictionary<string, object>{}, default, default, default);
        }

        /// <summary>
        /// Invokes the 9.Terminals/Terminal.xaml
        /// </summary>
        public string Terminal(string in_Keyword, string in_Code)
        {
            var result = _runWorkflowHandler(@"9.Terminals\Terminal.xaml", new Dictionary<string, object>{{"in_Keyword", in_Keyword}, {"in_Code", in_Code}}, default, default, default);
            return (string)result["out_Result"];
        }
    }
}