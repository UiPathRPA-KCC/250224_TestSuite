using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using UiPath.CodedWorkflows;
using UiPath.Activities.Contracts;

namespace RPATestingExercise
{
    public class WorkflowRunnerService
    {
        private readonly Func<string, IDictionary<string, object>, TimeSpan?, bool, InvokeTargetSession, IDictionary<string, object>> _runWorkflowHandler;
        public WorkflowRunnerService(Func<string, IDictionary<string, object>, TimeSpan?, bool, InvokeTargetSession, IDictionary<string, object>> runWorkflowHandler)
        {
            _runWorkflowHandler = runWorkflowHandler;
        }

        /// <summary>
        /// Invokes the Tests/InitAllSettingsTestCase.xaml
        /// </summary>
        public void InitAllSettingsTestCase()
        {
            var result = _runWorkflowHandler(@"Tests\InitAllSettingsTestCase.xaml", new Dictionary<string, object>{}, default, default, default);
        }

        /// <summary>
        /// Invokes the Framework/InitAllSettings.xaml
        /// </summary>
        public System.Collections.Generic.Dictionary<string, object> InitAllSettings(string in_ConfigFile, string[] in_ConfigSheets)
        {
            var result = _runWorkflowHandler(@"Framework\InitAllSettings.xaml", new Dictionary<string, object>{{"in_ConfigFile", in_ConfigFile}, {"in_ConfigSheets", in_ConfigSheets}}, default, default, default);
            return (System.Collections.Generic.Dictionary<string, object>)result["out_Config"];
        }

        /// <summary>
        /// Invokes the Framework/TakeScreenshot.xaml
        /// </summary>
        public string TakeScreenshot(string in_Folder, string io_FilePath)
        {
            var result = _runWorkflowHandler(@"Framework\TakeScreenshot.xaml", new Dictionary<string, object>{{"in_Folder", in_Folder}, {"io_FilePath", io_FilePath}}, default, default, default);
            return (string)result["io_FilePath"];
        }

        /// <summary>
        /// Invokes the Framework/CloseAllApplications.xaml
        /// </summary>
        public void CloseAllApplications()
        {
            var result = _runWorkflowHandler(@"Framework\CloseAllApplications.xaml", new Dictionary<string, object>{}, default, default, default);
        }

        /// <summary>
        /// Invokes the Tests/MainTestCase.xaml
        /// </summary>
        public void MainTestCase()
        {
            var result = _runWorkflowHandler(@"Tests\MainTestCase.xaml", new Dictionary<string, object>{}, default, default, default);
        }

        /// <summary>
        /// Invokes the Tests/GetTransactionDataTestCase.xaml
        /// </summary>
        public void GetTransactionDataTestCase()
        {
            var result = _runWorkflowHandler(@"Tests\GetTransactionDataTestCase.xaml", new Dictionary<string, object>{}, default, default, default);
        }

        /// <summary>
        /// Invokes the Framework/Process.xaml
        /// </summary>
        public void Process(UiPath.Core.QueueItem in_TransactionItem, System.Collections.Generic.Dictionary<string, object> in_Config)
        {
            var result = _runWorkflowHandler(@"Framework\Process.xaml", new Dictionary<string, object>{{"in_TransactionItem", in_TransactionItem}, {"in_Config", in_Config}}, default, default, default);
        }

        /// <summary>
        /// Invokes the 05.UiPathTestDataManagement/05.3.TDQDataDriven/AddInvoiceFields.xaml
        /// </summary>
        public void AddInvoiceFields(string InvoiceNumber, string VendorTaxID, string InvoiceDate, string InvoiceCurrency, string ItemDescription, string UntaxedAmount, string TaxAmount, string TotalAmount)
        {
            var result = _runWorkflowHandler(@"05.UiPathTestDataManagement\05.3.TDQDataDriven\AddInvoiceFields.xaml", new Dictionary<string, object>{{"InvoiceNumber", InvoiceNumber}, {"VendorTaxID", VendorTaxID}, {"InvoiceDate", InvoiceDate}, {"InvoiceCurrency", InvoiceCurrency}, {"ItemDescription", ItemDescription}, {"UntaxedAmount", UntaxedAmount}, {"TaxAmount", TaxAmount}, {"TotalAmount", TotalAmount}}, default, default, default);
        }

        /// <summary>
        /// Invokes the 07.Mocking/Main.xaml
        /// </summary>
        public void Main(string in_OrchestratorQueueName, string in_OrchestratorQueueFolder)
        {
            var result = _runWorkflowHandler(@"07.Mocking\Main.xaml", new Dictionary<string, object>{{"in_OrchestratorQueueName", in_OrchestratorQueueName}, {"in_OrchestratorQueueFolder", in_OrchestratorQueueFolder}}, default, default, default);
        }

        /// <summary>
        /// Invokes the 06.TestExplorer/LoanQualificationTestCase.xaml
        /// </summary>
        public void LoanQualificationTestCase(string Name, int LoanAmount, int YearlyIncome, int Age, bool ExistingCustomer, string Country)
        {
            var result = _runWorkflowHandler(@"06.TestExplorer\LoanQualificationTestCase.xaml", new Dictionary<string, object>{{"Name", Name}, {"LoanAmount", LoanAmount}, {"YearlyIncome", YearlyIncome}, {"Age", Age}, {"ExistingCustomer", ExistingCustomer}, {"Country", Country}}, default, default, default);
        }

        /// <summary>
        /// Invokes the 04.AutomaticRPATestDataCreation/LoanQualification(AutoDataCreation).xaml
        /// </summary>
        public void LoanQualification_AutoDataCreation_(string Name, int LoanAmount, int YearlyIncome, int Age, bool ExistingCustomer, string Country)
        {
            var result = _runWorkflowHandler(@"04.AutomaticRPATestDataCreation\LoanQualification(AutoDataCreation).xaml", new Dictionary<string, object>{{"Name", Name}, {"LoanAmount", LoanAmount}, {"YearlyIncome", YearlyIncome}, {"Age", Age}, {"ExistingCustomer", ExistingCustomer}, {"Country", Country}}, default, default, default);
        }

        /// <summary>
        /// Invokes the Framework/SetTransactionStatus.xaml
        /// </summary>
        public (int io_RetryNumber, int io_TransactionNumber, int io_ConsecutiveSystemExceptions) SetTransactionStatus(UiPath.Core.BusinessRuleException in_BusinessException, string in_TransactionField1, string in_TransactionField2, string in_TransactionID, System.Exception in_SystemException, System.Collections.Generic.Dictionary<string, object> in_Config, System.Data.DataRow in_TransactionItem, int io_RetryNumber, int io_TransactionNumber, int io_ConsecutiveSystemExceptions)
        {
            var result = _runWorkflowHandler(@"Framework\SetTransactionStatus.xaml", new Dictionary<string, object>{{"in_BusinessException", in_BusinessException}, {"in_TransactionField1", in_TransactionField1}, {"in_TransactionField2", in_TransactionField2}, {"in_TransactionID", in_TransactionID}, {"in_SystemException", in_SystemException}, {"in_Config", in_Config}, {"in_TransactionItem", in_TransactionItem}, {"io_RetryNumber", io_RetryNumber}, {"io_TransactionNumber", io_TransactionNumber}, {"io_ConsecutiveSystemExceptions", io_ConsecutiveSystemExceptions}}, default, default, default);
            return ((int)result["io_RetryNumber"], (int)result["io_TransactionNumber"], (int)result["io_ConsecutiveSystemExceptions"]);
        }

        /// <summary>
        /// Invokes the 06.TestExplorer/ProcessTestCase.xaml
        /// </summary>
        public void _06_TestExplorer_ProcessTestCase()
        {
            var result = _runWorkflowHandler(@"06.TestExplorer\ProcessTestCase.xaml", new Dictionary<string, object>{}, default, default, default);
        }

        /// <summary>
        /// Invokes the 05.UiPathTestDataManagement/05.1.SyntheticData/AddVendorFields.xaml
        /// </summary>
        public void AddVendorFields(string Address, string City, string Country, string Name, string VendorTaxID)
        {
            var result = _runWorkflowHandler(@"05.UiPathTestDataManagement\05.1.SyntheticData\AddVendorFields.xaml", new Dictionary<string, object>{{"Address", Address}, {"City", City}, {"Country", Country}, {"Name", Name}, {"VendorTaxID", VendorTaxID}}, default, default, default);
        }

        /// <summary>
        /// Invokes the 02.TestCasesAndUiAutomation/InitAllApplicationsTestCase.xaml
        /// </summary>
        public void _02_TestCasesAndUiAutomation_InitAllApplicationsTestCase()
        {
            var result = _runWorkflowHandler(@"02.TestCasesAndUiAutomation\InitAllApplicationsTestCase.xaml", new Dictionary<string, object>{}, default, default, default);
        }

        /// <summary>
        /// Invokes the Tests/ProcessTestCase.xaml
        /// </summary>
        public void ProcessTestCase()
        {
            var result = _runWorkflowHandler(@"Tests\ProcessTestCase.xaml", new Dictionary<string, object>{}, default, default, default);
        }

        /// <summary>
        /// Invokes the Framework/RetryCurrentTransaction.xaml
        /// </summary>
        public (int io_RetryNumber, int io_TransactionNumber) RetryCurrentTransaction(System.Collections.Generic.Dictionary<string, object> in_Config, System.Exception in_SystemException, bool in_QueueRetry, int io_RetryNumber, int io_TransactionNumber)
        {
            var result = _runWorkflowHandler(@"Framework\RetryCurrentTransaction.xaml", new Dictionary<string, object>{{"in_Config", in_Config}, {"in_SystemException", in_SystemException}, {"in_QueueRetry", in_QueueRetry}, {"io_RetryNumber", io_RetryNumber}, {"io_TransactionNumber", io_TransactionNumber}}, default, default, default);
            return ((int)result["io_RetryNumber"], (int)result["io_TransactionNumber"]);
        }

        /// <summary>
        /// Invokes the Framework/KillAllProcesses.xaml
        /// </summary>
        public void KillAllProcesses()
        {
            var result = _runWorkflowHandler(@"Framework\KillAllProcesses.xaml", new Dictionary<string, object>{}, default, default, default);
        }

        /// <summary>
        /// Invokes the Framework/GetTransactionData.xaml
        /// </summary>
        public (string out_TransactionField1, string out_TransactionField2, string out_TransactionID, UiPath.Core.QueueItem out_TransactionItem, System.Data.DataTable io_dt_TransactionData) GetTransactionData(int in_TransactionNumber, System.Collections.Generic.Dictionary<string, object> in_Config, System.Data.DataTable io_dt_TransactionData)
        {
            var result = _runWorkflowHandler(@"Framework\GetTransactionData.xaml", new Dictionary<string, object>{{"in_TransactionNumber", in_TransactionNumber}, {"in_Config", in_Config}, {"io_dt_TransactionData", io_dt_TransactionData}}, default, default, default);
            return ((string)result["out_TransactionField1"], (string)result["out_TransactionField2"], (string)result["out_TransactionID"], (UiPath.Core.QueueItem)result["out_TransactionItem"], (System.Data.DataTable)result["io_dt_TransactionData"]);
        }

        /// <summary>
        /// Invokes the 05.UiPathTestDataManagement/05.1.SyntheticData/AddData.xaml
        /// </summary>
        public void AddData()
        {
            var result = _runWorkflowHandler(@"05.UiPathTestDataManagement\05.1.SyntheticData\AddData.xaml", new Dictionary<string, object>{}, default, default, default);
        }

        /// <summary>
        /// Invokes the 03.DataDrivenTestCase/TC_VaildateInvoiceData.xaml
        /// </summary>
        public void TC_VaildateInvoiceData(string Vendor, string Month, string Amount, string Tax, string Total, string Currency, string ExpectedResult)
        {
            var result = _runWorkflowHandler(@"03.DataDrivenTestCase\TC_VaildateInvoiceData.xaml", new Dictionary<string, object>{{"Vendor", Vendor}, {"Month", Month}, {"Amount", Amount}, {"Tax", Tax}, {"Total", Total}, {"Currency", Currency}, {"ExpectedResult", ExpectedResult}}, default, default, default);
        }

        /// <summary>
        /// Invokes the 06.TestExplorer/LoanQualification(TestExplorer).xaml
        /// </summary>
        public void LoanQualification_TestExplorer_(string Name, int LoanAmount, int YearlyIncome, int Age, bool ExistingCustomer, string Country)
        {
            var result = _runWorkflowHandler(@"06.TestExplorer\LoanQualification(TestExplorer).xaml", new Dictionary<string, object>{{"Name", Name}, {"LoanAmount", LoanAmount}, {"YearlyIncome", YearlyIncome}, {"Age", Age}, {"ExistingCustomer", ExistingCustomer}, {"Country", Country}}, default, default, default);
        }

        /// <summary>
        /// Invokes the 04.AutomaticRPATestDataCreation/TC_Loan.xaml
        /// </summary>
        public void TC_Loan(string Name, int LoanAmount, int YearlyIncome, int Age, bool ExistingCustomer, string Country)
        {
            var result = _runWorkflowHandler(@"04.AutomaticRPATestDataCreation\TC_Loan.xaml", new Dictionary<string, object>{{"Name", Name}, {"LoanAmount", LoanAmount}, {"YearlyIncome", YearlyIncome}, {"Age", Age}, {"ExistingCustomer", ExistingCustomer}, {"Country", Country}}, default, default, default);
        }

        /// <summary>
        /// Invokes the 01.SimpleTestCase/CalculateInvoiceTotal.xaml
        /// </summary>
        public int CalculateInvoiceTotal(int in_Amount, int in_Tax)
        {
            var result = _runWorkflowHandler(@"01.SimpleTestCase\CalculateInvoiceTotal.xaml", new Dictionary<string, object>{{"in_Amount", in_Amount}, {"in_Tax", in_Tax}}, default, default, default);
            return (int)result["out_Total"];
        }

        /// <summary>
        /// Invokes the Tests/WorkflowTestCaseTemplate.xaml
        /// </summary>
        public void WorkflowTestCaseTemplate()
        {
            var result = _runWorkflowHandler(@"Tests\WorkflowTestCaseTemplate.xaml", new Dictionary<string, object>{}, default, default, default);
        }

        /// <summary>
        /// Invokes the Tests/InitAllApplicationsTestCase.xaml
        /// </summary>
        public void InitAllApplicationsTestCase()
        {
            var result = _runWorkflowHandler(@"Tests\InitAllApplicationsTestCase.xaml", new Dictionary<string, object>{}, default, default, default);
        }

        /// <summary>
        /// Invokes the Framework/InitAllApplications.xaml
        /// </summary>
        public void InitAllApplications(System.Collections.Generic.Dictionary<string, object> in_Config)
        {
            var result = _runWorkflowHandler(@"Framework\InitAllApplications.xaml", new Dictionary<string, object>{{"in_Config", in_Config}}, default, default, default);
        }

        /// <summary>
        /// Invokes the 05.UiPathTestDataManagement/05.1.SyntheticData/TC_AddVendorField.xaml
        /// </summary>
        public void TC_AddVendorField(string TaxID, string Name, string StreetAddress, string Country, string City, System.Collections.Generic.IDictionary<string, object> testQ)
        {
            var result = _runWorkflowHandler(@"05.UiPathTestDataManagement\05.1.SyntheticData\TC_AddVendorField.xaml", new Dictionary<string, object>{{"TaxID", TaxID}, {"Name", Name}, {"StreetAddress", StreetAddress}, {"Country", Country}, {"City", City}, {"testQ", testQ}}, default, default, default);
        }

        /// <summary>
        /// Invokes the 03.DataDrivenTestCase/ValidateInvoiceData.xaml
        /// </summary>
        public bool ValidateInvoiceData(string in_Vendor, string in_Month, string in_Currency, string in_Tax, string in_Amount, string in_Total)
        {
            var result = _runWorkflowHandler(@"03.DataDrivenTestCase\ValidateInvoiceData.xaml", new Dictionary<string, object>{{"in_Vendor", in_Vendor}, {"in_Month", in_Month}, {"in_Currency", in_Currency}, {"in_Tax", in_Tax}, {"in_Amount", in_Amount}, {"in_Total", in_Total}}, default, default, default);
            return (bool)result["out_dataIsValid"];
        }

        /// <summary>
        /// Invokes the 01.SimpleTestCase/TC_Total.xaml
        /// </summary>
        public void TC_Total()
        {
            var result = _runWorkflowHandler(@"01.SimpleTestCase\TC_Total.xaml", new Dictionary<string, object>{}, default, default, default);
        }

        /// <summary>
        /// Invokes the 05.UiPathTestDataManagement/05.3.TDQDataDriven/TC_AddInvoiceField.xaml
        /// </summary>
        public void TC_AddInvoiceField(RPATestingExercise.Invoice invoice)
        {
            var result = _runWorkflowHandler(@"05.UiPathTestDataManagement\05.3.TDQDataDriven\TC_AddInvoiceField.xaml", new Dictionary<string, object>{{"invoice", invoice}}, default, default, default);
        }

        /// <summary>
        /// Invokes the 07.Mocking/ACME.xaml
        /// </summary>
        public void ACME(string WIID)
        {
            var result = _runWorkflowHandler(@"07.Mocking\ACME.xaml", new Dictionary<string, object>{{"WIID", WIID}}, default, default, default);
        }

        /// <summary>
        /// Invokes the WIID데이터추출.xaml
        /// </summary>
        public void WIID데이터추출()
        {
            var result = _runWorkflowHandler(@"WIID데이터추출.xaml", new Dictionary<string, object>{}, default, default, default);
        }

        /// <summary>
        /// Invokes the 사이트이동.xaml
        /// </summary>
        public string 사이트이동(string WIID)
        {
            var result = _runWorkflowHandler(@"사이트이동.xaml", new Dictionary<string, object>{{"WIID", WIID}}, default, default, default);
            return (string)result["WIID"];
        }

        /// <summary>
        /// Invokes the 07.Mocking/TC_ACME.xaml
        /// </summary>
        public void TC_ACME(string WIID)
        {
            var result = _runWorkflowHandler(@"07.Mocking\TC_ACME.xaml", new Dictionary<string, object>{{"WIID", WIID}}, default, default, default);
        }

        /// <summary>
        /// Invokes the Mocks/07.Mocking/ACME_mock.xaml
        /// </summary>
        public void ACME_mock(string WIID)
        {
            var result = _runWorkflowHandler(@"Mocks\07.Mocking\ACME_mock.xaml", new Dictionary<string, object>{{"WIID", WIID}}, default, default, default);
        }
    }
}