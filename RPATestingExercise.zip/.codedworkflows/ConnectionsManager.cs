using UiPath.CodedWorkflows;
using System;

namespace RPATestingExercise
{
    public class ConnectionsManager
    {
        public ConnectionsManager(ICodedWorkflowsServiceContainer resolver)
        {
        }
    }
}