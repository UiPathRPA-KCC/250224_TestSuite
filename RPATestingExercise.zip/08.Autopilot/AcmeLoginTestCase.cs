using System;
using System.Collections.Generic;
using System.Data;
using System.Security;
using RPATestingExercise;
using UiPath.CodedWorkflows;
using UiPath.Core;
using UiPath.Core.Activities.Storage;
using UiPath.Orchestrator.Client.Models;
using UiPath.Testing;
using UiPath.Testing.Activities.TestData;
using UiPath.Testing.Activities.TestDataQueues.Enums;
using UiPath.Testing.Enums;
using UiPath.UIAutomationNext.API.Contracts;
using UiPath.UIAutomationNext.API.Models;
using UiPath.UIAutomationNext.Enums;

namespace UpdateInvoices.Workflows._11.Autopilot
{
    public class AcmeLoginTestCase : CodedWorkflow
    {
        [TestCase]
        public void Execute()
        {
            // Retrieve credential named AcmeCredentials from orchestrator
            string credentialName = "AcmeCredentials";
            string folderPath = "";
            SecureString Password;
            string Email = system.GetCredential(credentialName,out Password, folderPath);
            // Given the ACME System 1 - Log In Screen, create actions to login into the application and test if login was successful
            
            
            
            
            
//            var loginScreenDescriptor = ObjectRepository.Descriptors.ACME.ACME_System_1___Log_In;
//            var screen = uiAutomation.Open(loginScreenDescriptor);
//            screen.TypeInto(loginScreenDescriptor.Email, Email);
//            screen.TypeInto(loginScreenDescriptor.Password, new System.Net.NetworkCredential(string.Empty, Password).Password);
//            screen.Click(loginScreenDescriptor.Login);
//            var loginSuccessful = screen.WaitState(loginScreenDescriptor.Login, NCheckStateMode.WaitDisappear,5);
//            testing.VerifyExpressionWithOperator(loginSuccessful,Comparison.Equality,true);
        }
    }
}